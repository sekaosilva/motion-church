// O que cada tecla e cada botão giratório faz. Sem nada de Ulanzi aqui dentro:
// o app.js liga isso aos eventos do Deck, e os testes chamam direto.

export const PLUGIN = 'br.seraph.ulanzistudio.deck';
export const MC = 'br.seraph.motionchurch';

export const PROGRAMAS = {
  'br.seraph.motionchurch': 'Motion Church',
  'com.adobe.Photoshop': 'Photoshop',
  'com.adobe.illustrator': 'Illustrator',
  'com.adobe.LightroomClassicCC7': 'Lightroom Classic',
  'com.corel.coreldrawsuite.2022.coreldraw': 'CorelDRAW',
  'com.lemon.lvoverseas': 'CapCut',
  'com.resolume.arena': 'Resolume Arena',
};

// Teclas do Motion Church (os mesmos atalhos do teclado do programa).
export const MC_TECLAS = {
  apagar: 'b',       // Apagar tela / Acender tela
  pausar: 'space',   // Pausar / Continuar os vídeos
  mudo: 'm',         // Som de todos os vídeos
  limpar: 'esc',     // Tira o versículo da Bíblia do ar
  saida: 'f',        // Liga e desliga a saída neste monitor
  letras: 'l',       // Abre a janela das letras
  proximo: 'right',  // Próxima parte da letra / próximo versículo
  anterior: 'left',
  salvar: 'cmd+s',
};

// Botões giratórios prontos: girar para a esquerda, para a direita e apertar.
export const GIROS = {
  'mc-passar':     { app: MC, nome: 'Letra / Bíblia', icone: 'arrow-left-right', esquerda: 'left', direita: 'right', apertar: 'esc', cor: '#2b9bff' },
  'ps-pincel':     { app: 'com.adobe.Photoshop', nome: 'Pincel', icone: 'brush', esquerda: '[', direita: ']', apertar: 'x', cor: '#31a8ff' },
  'ps-zoom':       { app: 'com.adobe.Photoshop', nome: 'Zoom', icone: 'zoom-in', esquerda: 'cmd+-', direita: 'cmd+=', apertar: 'cmd+0', cor: '#31a8ff' },
  'ps-historico':  { app: 'com.adobe.Photoshop', nome: 'Desfazer', icone: 'undo-2', esquerda: 'cmd+z', direita: 'cmd+shift+z', apertar: '', cor: '#31a8ff' },
  'ai-zoom':       { app: 'com.adobe.illustrator', nome: 'Zoom', icone: 'zoom-in', esquerda: 'cmd+-', direita: 'cmd+=', apertar: 'cmd+0', cor: '#ff9a00' },
  'ai-historico':  { app: 'com.adobe.illustrator', nome: 'Desfazer', icone: 'undo-2', esquerda: 'cmd+z', direita: 'cmd+shift+z', apertar: '', cor: '#ff9a00' },
  'cdr-historico': { app: 'com.corel.coreldrawsuite.2022.coreldraw', nome: 'Desfazer', icone: 'undo-2', esquerda: 'cmd+z', direita: 'cmd+shift+z', apertar: '', cor: '#3fbf5f' },
  'lr-ajuste':     { app: 'com.adobe.LightroomClassicCC7', nome: 'Ajuste', icone: 'sliders-horizontal', esquerda: '-', direita: '=', apertar: '.', cor: '#31a8ff' },
  'lr-fotos':      { app: 'com.adobe.LightroomClassicCC7', nome: 'Fotos', icone: 'image-down', esquerda: 'left', direita: 'right', apertar: 'p', cor: '#31a8ff' },
  'livre':         { app: '', nome: 'Giro', icone: 'sliders-horizontal', esquerda: '', direita: '', apertar: '', cor: '#9b7bff' },
};

export function giroDe(param = {}) {
  const base = GIROS[param.giro] || GIROS['ps-pincel'];
  if (param.giro !== 'livre') return { ...base, nome: param.nome || base.nome };
  return { ...base, app: param.app || '', nome: param.nome || 'Giro',
    esquerda: param.esquerda || '', direita: param.direita || '', apertar: param.apertar || '' };
}

export const pad2 = (n) => String(Math.floor(n)).padStart(2, '0');

export function formatarDuracao(ms) {
  const neg = ms < 0; let s = Math.floor(Math.abs(ms) / 1000);
  const h = Math.floor(s / 3600); s -= h * 3600;
  const m = Math.floor(s / 60); s -= m * 60;
  const txt = h ? `${h}:${pad2(m)}:${pad2(s)}` : `${pad2(m)}:${pad2(s)}`;
  return neg ? '+' + txt : txt;
}

// Cronômetro: conta para cima. Com limite (minutos), muda de cor perto do fim e passa a piscar quando estoura.
export class Cronometro {
  constructor(agora = Date.now) { this.agora = agora; this.inicio = 0; this.acumulado = 0; this.rodando = false; this.limiteMin = 0; }
  decorrido() { return this.acumulado + (this.rodando ? this.agora() - this.inicio : 0); }
  alternar() { if (this.rodando) { this.acumulado = this.decorrido(); this.rodando = false; } else { this.inicio = this.agora(); this.rodando = true; } }
  zerar() { this.acumulado = 0; this.inicio = this.agora(); this.rodando = false; }
  limite(min) { this.limiteMin = Math.max(0, Math.min(600, Math.round(Number(min) || 0))); }
  quadro(nome = 'Cronômetro') {
    const ms = this.decorrido();
    const lim = this.limiteMin * 60000;
    let cor = '#2fd27a', progresso = null, piscar = false, rot = nome;
    if (lim) {
      const resta = lim - ms;
      progresso = Math.min(1, ms / lim);
      if (resta <= 0) { cor = '#ff4d4f'; piscar = this.rodando && Math.floor(ms / 1000) % 2 === 0; rot = 'Passou ' + formatarDuracao(-resta).replace('+', ''); }
      else if (resta <= 5 * 60000) cor = '#ffb020';
    }
    if (!this.rodando && ms > 0) rot = 'Pausado';
    if (!this.rodando && ms === 0) rot = lim ? `${this.limiteMin} min` : nome;
    return { tempo: formatarDuracao(ms), nome: rot, cor, progresso, piscar };
  }
}

// Contagem para uma hora marcada (o início do culto). Depois da hora, conta quanto tempo já passou.
export function contagem(hora, nome = 'Culto', agora = new Date()) {
  const m = /^(\d{1,2})[:h.]?(\d{2})?$/.exec(String(hora || '').trim());
  const hh = m ? Math.min(23, +m[1]) : 19, mm = m && m[2] ? Math.min(59, +m[2]) : 0;
  const alvo = new Date(agora); alvo.setHours(hh, mm, 0, 0);
  // passou faz mais de 3 horas: a contagem é para amanhã
  if (agora - alvo > 3 * 3600000) alvo.setDate(alvo.getDate() + 1);
  const resta = alvo - agora;
  const horaTxt = `${pad2(hh)}:${pad2(mm)}`;
  if (resta > 0) {
    let cor = '#2fd27a';
    if (resta <= 60000) cor = '#ff4d4f'; else if (resta <= 10 * 60000) cor = '#ffb020';
    const progresso = resta <= 3600000 ? 1 - resta / 3600000 : null;
    return { tempo: formatarDuracao(Math.ceil(resta / 1000) * 1000), nome: `${nome} ${horaTxt}`, cor, progresso, piscar: false };
  }
  const passou = -resta;
  if (passou < 60000) return { tempo: 'AGORA', nome: `${nome} ${horaTxt}`, cor: '#ff4d4f', progresso: 1, piscar: Math.floor(passou / 1000) % 2 === 0 };
  return { tempo: formatarDuracao(passou), nome: 'Já começou', cor: '#2b9bff', progresso: null, piscar: false };
}
