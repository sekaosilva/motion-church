// Conversa com o sistema: qual programa está na frente, trazer um programa para a frente e apertar teclas nele.
// Mac: lsappinfo, open e System Events. Windows: PowerShell (WScript.Shell: AppActivate e SendKeys).
import { execFile } from 'child_process';
import { appendFileSync, existsSync } from 'fs';
import path from 'path';
export const WIN = (process.env.SERAPH_SO || process.platform) === 'win32';

// SERAPH_TESTE=arquivo: não roda nada no Mac, só anota os comandos (usado nos testes)
let frenteTeste = '';
const run = (cmd, args, timeout = 4000) => process.env.SERAPH_TESTE ? teste(cmd, args) : new Promise((resolve) => {
  execFile(cmd, args, { timeout }, (err, stdout, stderr) => resolve({ err, out: String(stdout || '').trim(), errOut: String(stderr || '').trim() }));
});
function teste(cmd, args) {
  const nome = cmd.split('/').pop();
  if (nome === 'lsappinfo') return Promise.resolve({ out: args[0] === 'front' ? 'ASN:0x1' : `"CFBundleIdentifier"="${frenteTeste}"` });
  appendFileSync(process.env.SERAPH_TESTE, JSON.stringify([nome, ...args]) + '\n');
  if (nome === 'open' && args[0] === '-b') frenteTeste = args[1];
  return Promise.resolve({ out: '' });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function programaDaFrente() {
  if (WIN) return '';
  const f = await run('/usr/bin/lsappinfo', ['front']);
  if (f.err || !f.out) return '';
  const i = await run('/usr/bin/lsappinfo', ['info', '-only', 'bundleid', f.out]);
  const m = /"(?:CFBundleIdentifier|bundleid)"\s*=\s*"([^"]+)"/i.exec(i.out);
  return m ? m[1] : '';
}

// Traz o programa para a frente (abre se estiver fechado). Devolve true quando ele ficou na frente.
export async function trazerParaFrente(bundleId) {
  if (!bundleId) return true;
  if (WIN) return winFrente(bundleId);
  if ((await programaDaFrente()) === bundleId) return true;
  const r = await run('/usr/bin/open', ['-b', bundleId]);
  if (r.err) return false;
  for (let i = 0; i < 30; i++) {
    await sleep(60);
    if ((await programaDaFrente()) === bundleId) { await sleep(120); return true; }
  }
  return false;
}

// Códigos das teclas que não são letras (independem do teclado ABNT ou americano).
const CODIGOS = {
  space: 49, espaco: 49, esc: 53, escape: 53, return: 36, enter: 36, tab: 48,
  left: 123, right: 124, down: 125, up: 126, esquerda: 123, direita: 124, baixo: 125, cima: 126,
  pageup: 116, pagedown: 121, home: 115, end: 119, delete: 51, backspace: 51, forwarddelete: 117,
  f1: 122, f2: 120, f3: 99, f4: 118, f5: 96, f6: 97, f7: 98, f8: 100, f9: 101, f10: 109, f11: 103, f12: 111,
};
const MODS = { cmd: 'command down', command: 'command down', '⌘': 'command down', shift: 'shift down', '⇧': 'shift down',
  alt: 'option down', option: 'option down', opt: 'option down', '⌥': 'option down', ctrl: 'control down', control: 'control down', '⌃': 'control down' };

// "cmd+shift+z", "space", "right", "[", "cmd+=" → um comando de AppleScript.
export function scriptDaTecla(spec) {
  const s = String(spec || '').trim();
  if (!s) return null;
  // separa por "+", mas deixa a tecla "+" sozinha funcionar ("cmd++")
  const partes = s === '+' ? ['+'] : s.replace(/\+\+$/, '+PLUS').split('+').map((p) => (p === 'PLUS' ? '+' : p));
  const tecla = partes.pop();
  const mods = partes.map((p) => MODS[p.toLowerCase()]).filter(Boolean);
  const usando = mods.length ? ` using {${[...new Set(mods)].join(', ')}}` : '';
  const cod = CODIGOS[tecla.toLowerCase()];
  if (cod != null) return `key code ${cod}${usando}`;
  if ([...tecla].length !== 1) return null;
  const ch = tecla === '"' ? '\\"' : tecla === '\\' ? '\\\\' : tecla.toLowerCase();
  return `keystroke "${ch}"${usando}`;
}

// Aperta uma ou mais teclas (separadas por espaço: "cmd+a cmd+c") no programa da frente.
export async function apertar(specs) {
  if (WIN) return winApertar(specs);
  const lista = String(specs || '').trim().split(/\s+/).filter(Boolean);
  const cmds = lista.map(scriptDaTecla).filter(Boolean);
  if (!cmds.length) return { ok: false, erro: 'atalho vazio' };
  const script = `tell application "System Events"\n${cmds.map((c) => '  ' + c).join('\n  delay 0.03\n')}\nend tell`;
  const r = await run('/usr/bin/osascript', ['-e', script]);
  if (r.err) return { ok: false, erro: r.errOut || String(r.err.message || r.err) };
  return { ok: true };
}

export async function abrir(bundleId) {
  if (WIN) return winAbrir(bundleId);
  const r = await run('/usr/bin/open', ['-b', bundleId]);
  return !r.err;
}

// ---------- Windows ----------
// título da janela de cada programa (o Deck no Windows só conversa com o Motion Church)
const JANELA = { 'br.seraph.motionchurch': 'Motion Church' };
const ps = (script) => run('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], 6000);
const aspas = (t) => "'" + String(t).replace(/'/g, "''") + "'";
async function winFrente(bundleId) {
  const t = JANELA[bundleId];
  if (!t) return true;
  const r = await ps(`$w=New-Object -ComObject WScript.Shell; if($w.AppActivate(${aspas(t)})){'sim'}else{'nao'}`);
  return !r.err && (process.env.SERAPH_TESTE || /sim/.test(r.out));
}
// "cmd+shift+z" → "^+z" (no Windows o Command do Mac é o Ctrl)
const WIN_TECLAS = { space: ' ', espaco: ' ', esc: '{ESC}', escape: '{ESC}', return: '{ENTER}', enter: '{ENTER}', tab: '{TAB}',
  left: '{LEFT}', right: '{RIGHT}', down: '{DOWN}', up: '{UP}', esquerda: '{LEFT}', direita: '{RIGHT}', baixo: '{DOWN}', cima: '{UP}',
  pageup: '{PGUP}', pagedown: '{PGDN}', home: '{HOME}', end: '{END}', delete: '{BACKSPACE}', backspace: '{BACKSPACE}', forwarddelete: '{DELETE}' };
const WIN_MODS = { cmd: '^', command: '^', '⌘': '^', ctrl: '^', control: '^', '⌃': '^', shift: '+', '⇧': '+', alt: '%', option: '%', opt: '%', '⌥': '%' };
export function sendKeysDe(spec) {
  const s = String(spec || '').trim();
  if (!s) return null;
  const partes = s === '+' ? ['+'] : s.replace(/\+\+$/, '+PLUS').split('+').map((p) => (p === 'PLUS' ? '+' : p));
  const tecla = partes.pop();
  const mods = [...new Set(partes.map((p) => WIN_MODS[p.toLowerCase()]).filter(Boolean))].join('');
  const low = tecla.toLowerCase();
  let k = WIN_TECLAS[low];
  if (!k && /^f([1-9]|1[0-2])$/.test(low)) k = `{${low.toUpperCase()}}`;
  if (!k) { if ([...tecla].length !== 1) return null; k = '+^%~(){}[]'.includes(tecla) ? `{${tecla}}` : low; }
  return mods + k;
}
async function winApertar(specs) {
  const lista = String(specs || '').trim().split(/\s+/).filter(Boolean).map(sendKeysDe).filter(Boolean);
  if (!lista.length) return { ok: false, erro: 'atalho vazio' };
  const r = await ps(`$w=New-Object -ComObject WScript.Shell; ${lista.map((k) => `$w.SendKeys(${aspas(k)}); Start-Sleep -Milliseconds 40`).join('; ')}`);
  if (r.err) return { ok: false, erro: r.errOut || String(r.err.message || r.err) };
  return { ok: true };
}
async function winAbrir(bundleId) {
  if (await winFrente(bundleId) && !process.env.SERAPH_TESTE) return true;
  const base = process.env.LOCALAPPDATA || path.join(process.env.USERPROFILE || '', 'AppData', 'Local');
  const exe = [path.join(base, 'Programs', 'Motion Church', 'Motion Church.exe'), path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Motion Church', 'Motion Church.exe')].find((f) => existsSync(f));
  if (!exe && !process.env.SERAPH_TESTE) return false;
  const r = await ps(`Start-Process -FilePath ${aspas(exe || 'Motion Church.exe')}`);
  return !r.err;
}
