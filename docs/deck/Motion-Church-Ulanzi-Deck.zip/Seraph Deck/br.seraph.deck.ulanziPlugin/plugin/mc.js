// Ligação direta com o Motion Church 2.22 ou mais novo (servidor dele em 127.0.0.1:47219).
// Com a ligação, o Deck sabe o que está no ar e manda comandos sem trazer o programa para a frente.
// Sem ela (Motion Church fechado ou antigo), o plugin volta a apertar as teclas do programa.
import http from 'http';

const PORTA = +process.env.SERAPH_MC_PORTA || 47219;
const H = { 'X-Seraph-Deck': '1' };

export class LigacaoMC {
  constructor(aoMudar) {
    this.aoMudar = aoMudar;
    this.estado = null;        // último resumo recebido (null = sem ligação)
    this.miniaturas = {};      // id da mídia -> data URL
    this.req = null;
    this.parado = false;
    this.conectar();
  }
  get ligado() { return !!this.estado; }
  conectar() {
    if (this.parado) return;
    const req = http.get({ host: '127.0.0.1', port: PORTA, path: '/eventos', headers: H }, (res) => {
      if (res.statusCode !== 200) { res.resume(); this.caiu(); return; }
      res.setEncoding('utf8');
      let buf = '';
      res.on('data', (d) => {
        buf += d;
        if (buf.length > 4e6) buf = '';
        let i;
        while ((i = buf.indexOf('\n\n')) >= 0) {
          const bloco = buf.slice(0, i); buf = buf.slice(i + 2);
          const linha = bloco.split('\n').find((l) => l.startsWith('data: '));
          if (!linha) continue;
          try { this.receber(JSON.parse(linha.slice(6))); } catch (_) {}
        }
      });
      res.on('end', () => this.caiu());
      res.on('error', () => this.caiu());
    });
    req.on('error', () => this.caiu());
    req.setTimeout(40000, () => req.destroy());   // o Motion Church manda um sinal a cada 15 s
    this.req = req;
  }
  receber(e) {
    if (!e || e.programa !== 'Motion Church') return;
    if (e.miniaturas) {
      const usadas = new Set((e.colunas || []).map((c) => c.thumb).filter(Boolean));
      for (const [id, url] of Object.entries(e.miniaturas)) this.miniaturas[id] = url;
      for (const id of Object.keys(this.miniaturas)) if (!usadas.has(id)) delete this.miniaturas[id];
      delete e.miniaturas;
    }
    const antes = this.estado;
    this.estado = e;
    this.aoMudar(e, antes);
  }
  caiu() {
    if (this.req) { try { this.req.destroy(); } catch (_) {} this.req = null; }
    const tinha = !!this.estado;
    this.estado = null;
    if (tinha) this.aoMudar(null, null);
    if (!this.parado) { clearTimeout(this.t); this.t = setTimeout(() => this.conectar(), 3000); }
  }
  comando(c) {
    return new Promise((resolve) => {
      const corpo = JSON.stringify(c);
      const req = http.request({ host: '127.0.0.1', port: PORTA, path: '/comando', method: 'POST', headers: { ...H, 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(corpo) } }, (res) => {
        res.resume(); resolve(res.statusCode === 200);
      });
      req.on('error', () => resolve(false));
      req.setTimeout(3000, () => { req.destroy(); resolve(false); });
      req.end(corpo);
    });
  }
  coluna(n) { return (this.estado && (this.estado.colunas || []).find((c) => c.n === n)) || null; }
  parar() { this.parado = true; clearTimeout(this.t); if (this.req) this.req.destroy(); }
}
