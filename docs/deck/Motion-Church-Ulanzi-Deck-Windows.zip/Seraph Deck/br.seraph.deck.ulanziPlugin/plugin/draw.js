// Desenho dos ícones das teclas (196 x 196) e das telinhas dos botões giratórios.
// Usado pelo serviço do plugin (ícones que mudam: cronômetro, contagem, números)
// e pelo script que gera os ícones fixos.
import { createCanvas, GlobalFonts, Path2D, loadImage } from '@napi-rs/canvas';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import path from 'path';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
// Fonte: Inter (licença OFL), a mais próxima da fonte do sistema da Apple que pode ir junto no plugin.
for (const [arq, nome] of [['Inter-SemiBold', 'Seraph SemiBold'], ['Inter-Bold', 'Seraph Bold'], ['InterDisplay-Bold', 'Seraph Display'], ['InterDisplay-SemiBold', 'Seraph DisplaySemi']]) {
  try { GlobalFonts.registerFromPath(path.join(ROOT, 'resources/fonts', arq + '.otf'), nome); } catch (_) {}
}
try { GlobalFonts.registerFromPath(path.join(ROOT, 'resources/fonts', 'SimbolosTeclas.ttf'), 'Seraph Simbolos'); } catch (_) {}
const GLYPHS = JSON.parse(readFileSync(path.join(ROOT, 'resources/glyphs.json'), 'utf8'));

export const S = 196;
// Cores do sistema da Apple no modo escuro (as mesmas do programa na 2.23).
export const COR = {
  fundo: '#1c1c1e',
  fundo2: '#2c2c2e',
  texto: '#f5f5f7',
  apagado: '#8e8e93',
  azul: '#0a84ff',
  vermelho: '#ff453a',
  ambar: '#ff9f0a',
  verde: '#30d158',
  roxo: '#bf5af2',
  amarelo: '#ffd60a',
  rosa: '#ff375f',
  indigo: '#5e5ce6',
  ciano: '#32ade6',
  verdeagua: '#00c7be',
  vinho: '#c7253e',
};
const ROT = 'rgba(245,245,247,.92)';   // nome embaixo
const TRILHO = 'rgba(255,255,255,.10)';

const hex = (c) => { const m = /^#?([0-9a-f]{6})$/i.exec(c || ''); if (!m) return [10, 132, 255]; const n = parseInt(m[1], 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
const rgba = (c, a) => { const [r, g, b] = hex(c); return `rgba(${r},${g},${b},${a})`; };

// Contorno "squircle" (cantos contínuos, como os ícones da Apple), em vez do canto redondo comum.
function squircle(ctx, x, y, w, h, r) {
  const k = r * 1.28;            // o canto começa antes e termina mais suave
  ctx.beginPath();
  ctx.moveTo(x + k, y);
  ctx.lineTo(x + w - k, y);
  ctx.bezierCurveTo(x + w - k * .35, y, x + w, y + k * .35, x + w, y + k);
  ctx.lineTo(x + w, y + h - k);
  ctx.bezierCurveTo(x + w, y + h - k * .35, x + w - k * .35, y + h, x + w - k, y + h);
  ctx.lineTo(x + k, y + h);
  ctx.bezierCurveTo(x + k * .35, y + h, x, y + h - k * .35, x, y + h - k);
  ctx.lineTo(x, y + k);
  ctx.bezierCurveTo(x, y + k * .35, x + k * .35, y, x + k, y);
  ctx.closePath();
}

function glyph(ctx, name, cx, cy, size, color, lw = 2) {
  const ds = GLYPHS[name];
  if (!ds) return;
  const k = size / 24;
  ctx.save();
  ctx.translate(cx - size / 2, cy - size / 2);
  ctx.scale(k, k);
  ctx.strokeStyle = color;
  ctx.lineWidth = lw;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  for (const d of ds) ctx.stroke(new Path2D(d));
  ctx.restore();
}

function fitText(ctx, text, maxW, size, weight = 'SemiBold') {
  let s = size;
  do { ctx.font = `${s}px "Seraph ${weight}", "Seraph Simbolos"`; if (ctx.measureText(text).width <= maxW) break; s -= 1; } while (s > 10);
  return s;
}

// Fundo da tecla: grafite com um leve brilho em cima, como um material.
function base(bg = COR.fundo) {
  const c = createCanvas(S, S);
  const ctx = c.getContext('2d');
  ctx.fillStyle = bg; ctx.fillRect(0, 0, S, S);
  if (bg === COR.fundo) {
    const g = ctx.createLinearGradient(0, 0, 0, S);
    g.addColorStop(0, 'rgba(255,255,255,.06)'); g.addColorStop(.55, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, S, S);
  }
  return { c, ctx };
}

function rotulo(ctx, label, color = ROT, y = 162, size = 23) {
  if (!label) return;
  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  fitText(ctx, label, S - 22, size, 'SemiBold');
  ctx.fillText(label, S / 2, y);
}

// Placa do símbolo: squircle cheio da cor da função, como os ícones da Apple, para reconhecer de longe no escuro.
// Cores claras (amarelo) levam o símbolo escuro. Ligado: a tecla inteira fica da cor e a placa vira branca.
const mistura = (a, b, t) => { const A = hex(a), B = hex(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join(''); };
const clara = (cor) => { const [r, g, b] = hex(cor); return (0.299 * r + 0.587 * g + 0.114 * b) > 170; };
const tinta = (cor, ligado) => ligado ? cor : (clara(cor) ? '#1c1c1e' : '#ffffff');
function placa(ctx, cor, ligado, cx, cy, lado) {
  const x = cx - lado / 2, y = cy - lado / 2;
  ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.45)'; ctx.shadowBlur = 12; ctx.shadowOffsetY = 4;
  squircle(ctx, x, y, lado, lado, lado * .25);
  if (ligado) ctx.fillStyle = '#ffffff';
  else { const g = ctx.createLinearGradient(0, y, 0, y + lado); g.addColorStop(0, mistura(cor, '#ffffff', .18)); g.addColorStop(1, cor); ctx.fillStyle = g; }
  ctx.fill(); ctx.restore();
  squircle(ctx, x + .5, y + .5, lado - 1, lado - 1, lado * .25); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.stroke();
}

// Tecla com um símbolo e um nome embaixo.
export function teclaIcone({ icone, nome, cor = COR.azul, ligado = false, faixa = null }) {
  const { c, ctx } = base(ligado ? cor : COR.fundo);
  const semNome = !nome;
  const cy = semNome ? S / 2 : 78, lado = semNome ? 132 : 108;
  placa(ctx, cor, ligado, S / 2, cy, lado);
  glyph(ctx, icone, S / 2, cy, lado * .56, tinta(cor, ligado), 2.4);
  if (faixa) { ctx.fillStyle = faixa; ctx.beginPath(); ctx.roundRect(S / 2 - 22, 8, 44, 6, 3); ctx.fill(); }
  rotulo(ctx, nome, ligado ? (clara(cor) ? '#1c1c1e' : '#ffffff') : ROT);
  return c.toBuffer('image/png');
}

// Tecla com um número grande (colunas do Motion Church).
export function teclaNumero({ numero, nome, cor = COR.azul }) {
  const { c, ctx } = base();
  placa(ctx, cor, false, S / 2, 78, 108);
  ctx.fillStyle = tinta(cor, false);
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  fitText(ctx, String(numero), 90, 66, 'Display');
  ctx.fillText(String(numero), S / 2, 81);
  rotulo(ctx, nome);
  return c.toBuffer('image/png');
}

// Tecla de atalho: o atalho numa tecla de teclado (capa clara com sombra) e o nome embaixo.
export function teclaAtalho({ topo, nome, cor = COR.roxo, icone = null, app = '' }) {
  const { c, ctx } = base();
  const y0 = app ? 10 : 0;
  if (app) {
    ctx.fillStyle = cor; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    fitText(ctx, app, S - 40, 17, 'SemiBold'); ctx.fillText(app, S / 2, 24);
  }
  if (icone) { placa(ctx, cor, false, S / 2, 80 + y0 / 2, 96); glyph(ctx, icone, S / 2, 80 + y0 / 2, 54, tinta(cor, false), 2.4); }
  else {
    const x = 26, y = 40 + y0, w = S - 52, h = 70;
    ctx.fillStyle = 'rgba(0,0,0,.45)'; squircle(ctx, x, y + 4, w, h, 16); ctx.fill();     // sombra da tecla
    const g = ctx.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, mistura(cor, '#ffffff', .18)); g.addColorStop(1, cor);
    ctx.fillStyle = g; squircle(ctx, x, y, w, h, 16); ctx.fill();
    ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.stroke();
    ctx.fillStyle = tinta(cor, false); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    fitText(ctx, topo || '', w - 22, 38, 'Bold');
    ctx.fillText(topo || '', S / 2, y + h / 2 + 1);
  }
  rotulo(ctx, nome);
  return c.toBuffer('image/png');
}

// Relógio grande: cronômetro e contagem. "progresso" de 0 a 1 desenha um anel fino, como o do Relógio da Apple.
export function teclaTempo({ tempo, nome, cor = COR.verde, progresso = null, piscar = false }) {
  const { c, ctx } = base(piscar ? cor : COR.fundo);
  const r = 82;
  if (progresso != null) {
    ctx.lineWidth = 9; ctx.lineCap = 'round';
    ctx.strokeStyle = piscar ? 'rgba(255,255,255,.28)' : TRILHO;
    ctx.beginPath(); ctx.arc(S / 2, S / 2, r, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = piscar ? '#ffffff' : cor;
    const p = Math.max(0, Math.min(1, progresso));
    if (p > 0) { ctx.beginPath(); ctx.arc(S / 2, S / 2, r, -Math.PI / 2, -Math.PI / 2 + p * Math.PI * 2); ctx.stroke(); }
  }
  ctx.fillStyle = piscar ? '#ffffff' : COR.texto;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  fitText(ctx, tempo, 132, 52, 'Display');
  ctx.fillText(tempo, S / 2, 92);
  ctx.fillStyle = piscar ? '#ffffff' : cor;
  fitText(ctx, nome || '', 116, 19, 'SemiBold');
  ctx.fillText(nome || '', S / 2, 135);
  return c.toBuffer('image/png');
}

export const dataUrl = (buf) => 'data:image/png;base64,' + buf.toString('base64');

// Tecla de coluna ligada ao Motion Church: a miniatura do clipe num cartão arredondado, o número numa cápsula e o nome.
// No ar, o cartão ganha um anel vermelho (como a grade do programa) e a cápsula fica vermelha.
export async function teclaColuna({ numero, nome, miniatura = '', vivo = false, vazia = false, tipo = '' }) {
  const { c, ctx } = base();
  const m = 10, cw = S - 2 * m, ch = 124, cx = m, cy = m;
  let temImg = false;
  ctx.save(); squircle(ctx, cx, cy, cw, ch, 18); ctx.clip();
  if (miniatura) {
    try {
      const img = await loadImage(Buffer.from(miniatura.split(',')[1] || '', 'base64'));
      const k = Math.max(cw / img.width, ch / img.height);
      ctx.drawImage(img, cx + (cw - img.width * k) / 2, cy + (ch - img.height * k) / 2, img.width * k, img.height * k);
      temImg = true;
    } catch (_) {}
  }
  if (!temImg) {
    ctx.fillStyle = COR.fundo2; ctx.fillRect(cx, cy, cw, ch);
    if (vazia) { ctx.setLineDash([5, 6]); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(255,255,255,.16)'; squircle(ctx, cx + 1, cy + 1, cw - 2, ch - 2, 17); ctx.stroke(); ctx.setLineDash([]); }
    else if (tipo === 'text') glyph(ctx, 'mic-vocal', S / 2, cy + ch / 2, 56, COR.rosa, 2.4);
  }
  if (vazia && temImg) { ctx.fillStyle = 'rgba(28,28,30,.6)'; ctx.fillRect(cx, cy, cw, ch); }
  ctx.restore();
  if (vivo) { ctx.lineWidth = 6; ctx.strokeStyle = COR.vermelho; squircle(ctx, cx - 1, cy - 1, cw + 2, ch + 2, 19); ctx.stroke(); }
  // número numa cápsula
  const t = String(numero);
  ctx.font = '28px "Seraph Display"';
  const pw = Math.max(44, ctx.measureText(t).width + 26);
  ctx.fillStyle = vivo ? COR.vermelho : COR.azul;
  ctx.beginPath(); ctx.roundRect(cx + 8, cy + 8, pw, 40, 20); ctx.fill();
  ctx.fillStyle = '#ffffff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(t, cx + 8 + pw / 2, cy + 29);
  // nome
  const n = vazia ? 'Vazia' : (nome || 'Coluna');
  rotulo(ctx, n, vazia ? COR.apagado : (vivo ? COR.vermelho : ROT), 164, 22);
  return c.toBuffer('image/png');
}

// Tecla "Abrir Motion Church": o ícone do programa; com o programa aberto e ligado, um ponto verde e "Aberto".
const APP_ICONE = path.join(ROOT, 'resources/mc-app.png');
export async function teclaApp({ aberto = false }) {
  const { c, ctx } = base();
  try {
    const img = await loadImage(APP_ICONE);
    // só o quadrado do ícone (o arquivo tem uma margem escura em volta), recortado em squircle e com sombra
    ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 16; ctx.shadowOffsetY = 6;
    squircle(ctx, 44, 18, 108, 108, 24); ctx.fillStyle = '#05080f'; ctx.fill(); ctx.restore();
    ctx.save(); squircle(ctx, 44, 18, 108, 108, 24); ctx.clip();
    ctx.drawImage(img, 33, 33, 130, 130, 40, 14, 116, 116); ctx.restore();
    squircle(ctx, 44.5, 18.5, 107, 107, 24); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,.14)'; ctx.stroke();
  } catch (_) {}
  if (aberto) {
    ctx.fillStyle = COR.fundo; ctx.beginPath(); ctx.arc(146, 118, 15, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = COR.verde; ctx.beginPath(); ctx.arc(146, 118, 10, 0, Math.PI * 2); ctx.fill();
  }
  rotulo(ctx, aberto ? 'Aberto' : 'Abrir', aberto ? COR.verde : ROT);
  return c.toBuffer('image/png');
}
