﻿# Instala o plugin Seraph no Ulanzi Studio (Windows) e coloca o perfil "Seraph" do Ulanzi Creative Deck (D200X).
$ErrorActionPreference = 'Stop'
$aqui = Split-Path -Parent $MyInvocation.MyCommand.Path
$PLUGIN = 'br.seraph.deck.ulanziPlugin'
$PERFIL = '5e7a9b10-5e7a-4f00-9c11-5e7a9b10ce01.ulanziProfile'
function Fim($msg) { if ($msg) { Write-Host $msg }; Write-Host ''; Read-Host 'Aperte Enter para fechar' | Out-Null; exit }
Write-Host '== Motion Church no Ulanzi Deck (plugin Seraph) =='

# pasta de dados do Ulanzi Studio (onde ficam Plugins e ProfilesV2)
$cands = @("$env:APPDATA\Ulanzi\UlanziDeck", "$env:APPDATA\Ulanzi\UlanziStudio", "$env:LOCALAPPDATA\Ulanzi\UlanziDeck", "$env:LOCALAPPDATA\Ulanzi\UlanziStudio")
$PASTA = $cands | Where-Object { Test-Path (Join-Path $_ 'ProfilesV2') } | Select-Object -First 1
if (-not $PASTA) {
  foreach ($raiz in @("$env:APPDATA\Ulanzi", "$env:LOCALAPPDATA\Ulanzi")) {
    if (Test-Path $raiz) { $p = Get-ChildItem $raiz -Directory -Recurse -Depth 3 -Filter 'ProfilesV2' -ErrorAction SilentlyContinue | Select-Object -First 1; if ($p) { $PASTA = $p.Parent.FullName; break } }
  }
}
if (-not $PASTA) { Fim 'Não achei a pasta do Ulanzi Studio. Ligue o Deck no computador, abra o Ulanzi Studio uma vez e rode de novo.' }

# número do Deck D200X deste computador (está nos perfis que o Ulanzi Studio já criou)
$DECK = $null
foreach ($f in Get-ChildItem (Join-Path $PASTA 'ProfilesV2') -Filter manifest.json -Recurse -Depth 1 -ErrorAction SilentlyContinue) {
  $m = [regex]::Match((Get-Content $f.FullName -Raw -Encoding UTF8), '"Model"\s*:\s*"D200X"\s*,\s*"UUID"\s*:\s*"([^"]+)"')
  if ($m.Success -and $m.Groups[1].Value -ne '__DECK__') { $DECK = $m.Groups[1].Value; break }
}
if (-not $DECK) { Fim 'Não achei o Ulanzi Creative Deck (D200X) no Ulanzi Studio. Ligue o Deck no computador, abra o Ulanzi Studio uma vez e rode de novo.' }

Write-Host 'Fechando o Ulanzi Studio...'
$exe = $null
$ps = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like '*Ulanzi*' }
foreach ($p in $ps) { if (-not $exe -and $p.Path -and $p.Path -like '*Ulanzi Studio*.exe') { $exe = $p.Path } }
$ps | Stop-Process -Force -ErrorAction SilentlyContinue
try { Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*$PLUGIN*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } } catch {}
Start-Sleep -Seconds 2

New-Item -ItemType Directory -Force -Path (Join-Path $PASTA 'Plugins') | Out-Null
$dest = Join-Path $PASTA "Plugins\$PLUGIN"
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
Copy-Item (Join-Path $aqui $PLUGIN) $dest -Recurse
try { Get-ChildItem $dest -Recurse | Unblock-File -ErrorAction SilentlyContinue } catch {}
Write-Host 'Plugin instalado.'

$pdest = Join-Path $PASTA "ProfilesV2\$PERFIL"
if (Test-Path $pdest) { Remove-Item $pdest -Recurse -Force }
Copy-Item (Join-Path $aqui "perfil\$PERFIL") $pdest -Recurse
$perfis = (Join-Path $PASTA 'ProfilesV2') -replace '\\', '/'
$utf8 = New-Object System.Text.UTF8Encoding($false)
foreach ($f in Get-ChildItem $pdest -Filter manifest.json -Recurse) {
  $t = [IO.File]::ReadAllText($f.FullName, $utf8).Replace('__PERFIS__', $perfis).Replace('__DECK__', $DECK)
  [IO.File]::WriteAllText($f.FullName, $t, $utf8)
}
Write-Host 'Perfil Seraph colocado (4 páginas do Motion Church).'

if (-not $exe) { $exe = @("$env:ProgramFiles\Ulanzi Studio\Ulanzi Studio.exe", "${env:ProgramFiles(x86)}\Ulanzi Studio\Ulanzi Studio.exe", "$env:LOCALAPPDATA\Programs\Ulanzi Studio\Ulanzi Studio.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1 }
if ($exe) { Write-Host 'Abrindo o Ulanzi Studio...'; Start-Process -FilePath $exe } else { Write-Host 'Abra o Ulanzi Studio.' }
Fim 'Pronto. No Ulanzi Studio, escolha o perfil Seraph.'
