// Serviço do plugin Seraph para o Ulanzi Deck (D200X).
// O Ulanzi Studio roda este arquivo com o Node dele e passa endereço, porta e idioma.
import UlanziApi from '../libs/node-sdk/index.js';
import { appendFileSync, mkdirSync } from 'fs';
import os from 'os';
import path from 'path';
import { PLUGIN, MC, MC_TECLAS, PROGRAMAS, Cronometro, contagem, giroDe } from './acoes.js';
import { teclaIcone, teclaNumero, teclaAtalho, teclaTempo, teclaColuna, teclaApp, dataUrl, COR } from './draw.js';
import { LigacaoMC } from './mc.js';
import { trazerParaFrente, apertar, abrir, WIN } from './mac.js';

import { fileURLToPath } from 'url';
const LOGDIR = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'registro');
try { mkdirSync(LOGDIR, { recursive: true }); } catch (_) {}
const log = (...a) => { try { appendFileSync(path.join(LOGDIR, 'registro.log'), `[${new Date().toISOString()}] ${a.join(' ')}\n`); } catch (_) {} };

const $UD = new UlanziApi();
const A = (s) => `${PLUGIN}.${s}`;
const INST = new Map();           // context -> { acao, param, ativo, ultimo, cron? }
const MCE = { apagar: false, mudo: false, pausar: false };   // sem ligação: o que achamos que está ligado no Motion Church
const MC_ACOES = new Set(['mcBiblia', 'mcColuna', 'mcApagar', 'mcPausar', 'mcMudo', 'mcLimpar', 'mcSaida', 'mcPassar', 'mcParar', 'mcAbrir', 'mcColunas']);
// ligação direta com o Motion Church 2.22+: quando o estado muda, redesenha as teclas dele
const link = new LigacaoMC((e, antes) => {
  if (!!e !== !!antes) log(e ? 'ligado ao Motion Church' : 'sem ligação com o Motion Church');
  for (const [ctx, i] of INST) if (MC_ACOES.has(i.acao) || (i.acao === 'giro' && giroDe(i.param).app === MC)) desenhar(ctx);
});
// estado de uma luz: com ligação vem do Motion Church; sem ela, do que o Deck mandou
const luz = (chave) => { const e = link.estado; if (!e) return MCE[chave]; return { apagar: e.preto, pausar: e.pausado, mudo: e.mudo }[chave]; };
let avisouPermissao = false;

const acaoDe = (msg) => String(msg.uuid || (msg.context || '').split('___')[0] || '').slice(PLUGIN.length + 1);

function inst(msg) {
  const ctx = msg.context;
  let i = INST.get(ctx);
  if (!i) { i = { acao: acaoDe(msg), param: {}, ativo: true, ultimo: '' }; INST.set(ctx, i); }
  if (msg.param && typeof msg.param === 'object' && !Array.isArray(msg.param)) i.param = { ...i.param, ...msg.param };
  if (i.acao === 'cronometro') {
    if (!i.cron) i.cron = new Cronometro();
    if (i.param.limite != null && !i.mexeuLimite) i.cron.limite(i.param.limite);
  }
  return i;
}

function icone(ctx, buf, titulo = '') {
  const i = INST.get(ctx);
  const chave = buf.length + ':' + titulo + ':' + buf.subarray(buf.length - 64).toString('base64');
  if (i && i.ultimo === chave) return;
  if (i) i.ultimo = chave;
  $UD.setBaseDataIcon(ctx, dataUrl(buf), titulo);
}

function desenhar(ctx, forcar = false) {
  const i = INST.get(ctx);
  if (!i) return;
  if (forcar) i.ultimo = '';
  const p = i.param;
  switch (i.acao) {
    case 'mcColuna': {
      const n = Math.max(1, Math.min(99, parseInt(p.coluna, 10) || 1));
      const col = link.coluna(n);
      if (!col) return icone(ctx, teclaNumero({ numero: n, nome: p.nome || 'Coluna' }));
      const ver = ++i.versao || (i.versao = 1);
      teclaColuna({ numero: n, nome: p.nome || col.nome, miniatura: link.miniaturas[col.thumb] || '', vivo: col.vivo, vazia: col.vazia, tipo: col.tipo })
        .then((buf) => { if (i.versao === ver && INST.get(ctx) === i) icone(ctx, buf); }).catch((e) => log('coluna', e.stack || e));
      return undefined;
    }
    case 'mcApagar': { const on = luz('apagar'); return icone(ctx, teclaIcone({ icone: 'monitor-off', nome: on ? 'Acender' : 'Apagar tela', cor: COR.vermelho, ligado: on })); }
    case 'mcPausar': { const on = luz('pausar'); return icone(ctx, teclaIcone({ icone: on ? 'play' : 'pause', nome: on ? 'Continuar' : 'Pausar', cor: COR.ambar, ligado: on })); }
    case 'mcMudo':   { const on = luz('mudo'); return icone(ctx, teclaIcone({ icone: on ? 'volume-x' : 'volume-2', nome: on ? 'Sem som' : 'Som', cor: COR.amarelo, ligado: on })); }
    case 'mcLimpar': { const on = !!(link.estado && link.estado.biblia); return icone(ctx, teclaIcone({ icone: 'book-x', nome: 'Tirar Bíblia', cor: COR.indigo, ligado: on })); }
    case 'mcSaida':  { const on = !!(link.estado && link.estado.saida); return icone(ctx, teclaIcone({ icone: 'maximize', nome: 'Saída', cor: COR.verdeagua, ligado: on })); }
    case 'mcParar':  return icone(ctx, teclaIcone({ icone: 'square-x', nome: 'Parar tudo', cor: COR.vinho }));
    case 'mcAbrir': {
      const ver = (i.versao = (i.versao || 0) + 1);
      teclaApp({ aberto: link.ligado }).then((buf) => { if (i.versao === ver && INST.get(ctx) === i) icone(ctx, buf); }).catch((e) => log('abrir', e.stack || e));
      return undefined;
    }
    case 'mcColunas': {
      const n = i.sel || (i.sel = 1);
      const col = link.coluna(n);
      const titulo = i.encoder ? `Coluna ${n}` : '';
      if (!col) return icone(ctx, teclaNumero({ numero: n, nome: 'Girar e apertar' }), titulo);
      const ver = (i.versao = (i.versao || 0) + 1);
      teclaColuna({ numero: n, nome: col.nome, miniatura: link.miniaturas[col.thumb] || '', vivo: col.vivo, vazia: col.vazia, tipo: col.tipo })
        .then((buf) => { if (i.versao === ver && INST.get(ctx) === i) icone(ctx, buf, titulo); }).catch((e) => log('colunas', e.stack || e));
      return undefined;
    }
    case 'mcPassar': {
      const prox = (p.direcao || 'proximo') !== 'anterior';
      return icone(ctx, teclaIcone({ icone: prox ? 'chevron-right' : 'chevron-left', nome: prox ? 'Próximo' : 'Anterior', cor: COR.azul }));
    }
    case 'cronometro': {
      const q = i.cron.quadro(p.nome || 'Cronômetro');
      return icone(ctx, teclaTempo(q), i.encoder ? (p.nome || 'Cronômetro') : '');
    }
    case 'contagem': return icone(ctx, teclaTempo(contagem(p.hora || '19:00', p.nome || 'Culto')));
    case 'atalho': return icone(ctx, teclaAtalho({ topo: p.topo || mostrarAtalho(p.teclas), nome: p.nome || 'Atalho', cor: p.cor || COR.roxo, app: p.app ? (PROGRAMAS[p.app] || '').replace('Lightroom Classic', 'Lightroom') : '' }));
    case 'giro': {
      const g = giroDe(p);
      let titulo = g.nome;
      const e = link.estado;
      if (g.app === MC && e) {
        if (e.ultimo === 'biblia' && e.biblia) titulo = e.biblia.replace(/ \(.*\)$/, '');
        else if (e.letra && e.letra.parte) titulo = `Parte ${e.letra.parte} de ${e.letra.total}`;
      }
      return icone(ctx, teclaIcone({ icone: g.icone, nome: '', cor: g.cor }), titulo);
    }
    default: return undefined;
  }
}

// "cmd+shift+z" → "⇧⌘Z" para mostrar na tecla
function mostrarAtalho(spec) {
  const s = String(spec || '').trim().split(/\s+/)[0] || '';
  if (!s) return '…';
  const sim = { cmd: '⌘', command: '⌘', shift: '⇧', alt: '⌥', option: '⌥', opt: '⌥', ctrl: '⌃', control: '⌃' };
  const partes = s.split('+'); const t = partes.pop();
  const ord = ['⌃', '⌥', '⇧', '⌘'];
  const mods = partes.map((x) => sim[x.toLowerCase()] || '').sort((a, b) => ord.indexOf(a) - ord.indexOf(b)).join('');
  const nomes = { space: 'Espaço', esc: 'Esc', left: '←', right: '→', up: '↑', down: '↓', return: '↩', enter: '↩', tab: '⇥' };
  return mods + (nomes[t.toLowerCase()] || t.toUpperCase());
}

async function mandar(ctx, app, teclas) {
  if (!teclas) return true;
  const naFrente = await trazerParaFrente(app);
  if (!naFrente) {
    $UD.showAlert(ctx);
    $UD.toast(`Não consegui trazer o ${PROGRAMAS[app] || 'programa'} para a frente. Ele está instalado?`);
    return false;
  }
  const r = await apertar(teclas);
  if (!r.ok) {
    log('falhou', app, teclas, r.erro);
    $UD.showAlert(ctx);
    if (!avisouPermissao) {
      avisouPermissao = true;
      $UD.toast(WIN ? 'O Windows não deixou apertar as teclas. Abra o Motion Church 2.22 ou mais novo, que o Deck fala direto com ele.' : 'O Mac bloqueou as teclas. Em Ajustes do Sistema > Privacidade e Segurança, ligue o Ulanzi Studio em Acessibilidade e em Automação.');
    }
    return false;
  }
  return true;
}

function redesenharAcao(acao) { for (const [ctx, i] of INST) if (i.acao === acao) desenhar(ctx); }

// Aperto da tecla. "longo" = segurou mais de 0,8 s.
async function apertou(ctx, longo) {
  const i = INST.get(ctx);
  if (!i) return;
  const p = i.param;
  // com ligação: comando direto; sem ela (ou se falhar): a tecla do programa
  const fazer = async (cmd, tecla) => {
    if (link.ligado && await link.comando(cmd)) return true;
    if (!tecla) { $UD.showAlert(ctx); $UD.toast('Para isso, abra o Motion Church 2.22 ou mais novo.'); return false; }
    return mandar(ctx, MC, tecla);
  };
  const alternar = async (chave, cmd, teclaMc) => {
    if (link.ligado) { await fazer({ acao: cmd }, teclaMc); return; }   // a luz vem do próprio Motion Church
    if (longo) { MCE[chave] = !MCE[chave]; redesenharAcao(i.acao); return; }   // só acerta a luz da tecla
    if (await mandar(ctx, MC, teclaMc)) { MCE[chave] = !MCE[chave]; redesenharAcao(i.acao); }
  };
  switch (i.acao) {
    case 'mcColuna': { const n = Math.max(1, Math.min(99, parseInt(p.coluna, 10) || 1)); return void fazer({ acao: 'coluna', n }, n <= 9 ? String(n) : ''); }
    case 'mcApagar': return alternar('apagar', 'preto', MC_TECLAS.apagar);
    case 'mcPausar': return alternar('pausar', 'pausar', MC_TECLAS.pausar);
    case 'mcMudo':   return alternar('mudo', 'mudo', MC_TECLAS.mudo);
    case 'mcLimpar': return void fazer({ acao: 'limpar' }, MC_TECLAS.limpar);
    case 'mcSaida':  return void fazer({ acao: 'saida' }, MC_TECLAS.saida);
    case 'mcLetras': return void fazer({ acao: 'letras' }, MC_TECLAS.letras);
    case 'mcParar':  return void fazer({ acao: 'parar' }, '');
    case 'mcAbrir':  return void (await abrir(MC));
    case 'mcColunas': { const n = i.sel || 1; return void fazer({ acao: 'coluna', n }, n <= 9 ? String(n) : ''); }
    case 'mcBiblia': return void fazer({ acao: 'biblia' }, '');
    case 'mcPassar': { const ant = (p.direcao || 'proximo') === 'anterior'; return void fazer({ acao: ant ? 'anterior' : 'proximo' }, ant ? MC_TECLAS.anterior : MC_TECLAS.proximo); }
    case 'cronometro': if (longo) i.cron.zerar(); else i.cron.alternar(); return desenhar(ctx);
    case 'contagem': return undefined;
    case 'atalho': return void mandar(ctx, p.app || '', p.teclas);
    case 'giro': {
      const g = giroDe(p);
      if (g.app === MC && link.ligado && await link.comando({ acao: 'limpar' })) return undefined;
      return void mandar(ctx, g.app, g.apertar);
    }
    default: return undefined;
  }
}

async function girou(ctx, lado) {
  const i = INST.get(ctx);
  if (!i) return;
  i.encoder = true;
  const dir = lado.endsWith('right');
  if (i.acao === 'cronometro') {
    i.mexeuLimite = true;
    i.cron.limite(i.cron.limiteMin + (dir ? 1 : -1) * (lado.startsWith('hold') ? 5 : 1));
    i.param.limite = String(i.cron.limiteMin);
    $UD.setSettings({ ...i.param }, ctx);
    return desenhar(ctx);
  }
  if (i.acao === 'mcColunas') {
    // com a ligação, pula as colunas vazias; sem ela, vai de 1 a 9 (as que o teclado do Motion Church dispara)
    const cols = link.estado ? (link.estado.colunas || []).filter((c) => !c.vazia).map((c) => c.n) : [];
    const lista = cols.length ? cols : Array.from({ length: link.estado ? Math.max(1, (link.estado.colunas || []).length) : 9 }, (_, k) => k + 1);
    const at = lista.indexOf(i.sel || 1);
    const passo = (dir ? 1 : -1) * (lado.startsWith('hold') ? 5 : 1);
    const k = at < 0 ? 0 : ((at + passo) % lista.length + lista.length) % lista.length;
    i.sel = lista[k];
    return desenhar(ctx);
  }
  if (i.acao === 'giro') {
    const g = giroDe(i.param);
    if (g.app === MC && link.ligado && await link.comando({ acao: dir ? 'proximo' : 'anterior' })) return undefined;
    return void mandar(ctx, g.app, dir ? g.direita : g.esquerda);
  }
  return undefined;
}

// ---------- eventos do Deck ----------
const desceu = new Map();   // context -> hora em que a tecla desceu

const ARGS = process.argv.slice(2);
let tentativas = 0;
function conectar() { process.argv.splice(2, process.argv.length, ...ARGS); $UD.connect(PLUGIN); }
conectar();
$UD.onConnected(() => { tentativas = 0; log('conectado'); for (const ctx of INST.keys()) desenhar(ctx, true); });
$UD.onError((e) => log('erro', String(e)));
// o Ulanzi Studio não reabre o plugin sozinho: tenta reconectar por um tempo e, se ele não voltar, encerra
$UD.onClose(() => {
  log('desconectado');
  if (++tentativas > 20) process.exit(0);
  setTimeout(conectar, Math.min(10000, 500 * 2 ** Math.min(tentativas, 5)));
});

$UD.onAdd((msg) => { log('add', JSON.stringify({ uuid: msg.uuid, key: msg.key, controller: msg.controller, param: msg.param })); const i = inst(msg); if (msg.controller === 'Encoder') i.encoder = true; desenhar(msg.context, true); });
$UD.onParamFromApp((msg) => { inst(msg); desenhar(msg.context, true); });
$UD.onParamFromPlugin((msg) => { const i = inst(msg); if (i.acao === 'cronometro' && msg.param && msg.param.limite != null) { i.mexeuLimite = false; i.cron.limite(msg.param.limite); } desenhar(msg.context, true); });
$UD.onSetActive((msg) => { const i = inst(msg); i.ativo = String(msg.active) === 'true'; if (i.ativo) desenhar(msg.context, true); });
$UD.onClear((msg) => { for (const it of msg.param || []) INST.delete(it.context); });

$UD.onKeyDown((msg) => { inst(msg); desceu.set(msg.context, Date.now()); });
$UD.onKeyUp((msg) => {
  const t = desceu.get(msg.context);
  if (t == null) return;
  desceu.delete(msg.context);
  INST.get(msg.context).viaTecla = Date.now();
  apertou(msg.context, Date.now() - t >= 800).catch((e) => log('erro', e.stack || e));
});
$UD.onRun((msg) => {
  const i = inst(msg);
  // o Deck manda "keydown/keyup" e também "run" no mesmo aperto: quem resolve é o keyup
  if (desceu.has(msg.context) || (i.viaTecla && Date.now() - i.viaTecla < 1500)) return;
  apertou(msg.context, false).catch((e) => log('erro', e.stack || e));
});

$UD.onDialDown((msg) => { const i = inst(msg); i.encoder = true; desceu.set(msg.context, Date.now()); });
$UD.onDialUp((msg) => {
  const t = desceu.get(msg.context);
  desceu.delete(msg.context);
  const i = INST.get(msg.context);
  if (!i) return;
  if (i.girouApertado) { i.girouApertado = false; return; }   // girou com ele apertado: não conta como aperto
  apertou(msg.context, t != null && Date.now() - t >= 800).catch((e) => log('erro', e.stack || e));
});
$UD.onDialRotate((msg) => {
  const i = inst(msg);
  const lado = String(msg.rotateEvent || '');
  if (lado.startsWith('hold')) i.girouApertado = true;
  girou(msg.context, lado).catch((e) => log('erro', e.stack || e));
});

// relógios: cronômetro e contagem se redesenham sozinhos
setInterval(() => {
  for (const [ctx, i] of INST) {
    if (!i.ativo) continue;
    if (i.acao === 'contagem' || (i.acao === 'cronometro' && (i.cron.rodando || i.cron.quadro().piscar))) desenhar(ctx);
  }
}, 250);

process.on('uncaughtException', (e) => log('exceção', e.stack || e));
process.on('unhandledRejection', (e) => log('rejeição', (e && e.stack) || e));
log('iniciado', process.argv.slice(2).join(' '));
