// Página de ajustes das teclas (comum a todas as ações do plugin Seraph).
(function () {
  const acao = document.body.dataset.acao;
  const form = document.querySelector('#property-inspector');
  const extra = () => { if (window.piExtra) window.piExtra(form); };
  $UD.connect('br.seraph.ulanzistudio.deck.' + acao);
  const carregar = (msg) => { if (msg && msg.param) Utils.setFormValue(msg.param, form); extra(); };
  $UD.onAdd(carregar);
  $UD.onParamFromApp(carregar);
  const enviar = () => { extra(); $UD.sendParamFromPlugin(Utils.getFormValue(form)); };
  form.addEventListener('change', enviar);
  form.addEventListener('input', () => { clearTimeout(form._t); form._t = setTimeout(enviar, 400); });
  extra();
})();
