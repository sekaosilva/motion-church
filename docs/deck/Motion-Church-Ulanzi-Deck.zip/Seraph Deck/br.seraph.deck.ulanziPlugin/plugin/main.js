// Entrada do plugin: anota no registro se algo falhar já ao carregar (por exemplo, a biblioteca de desenho).
import { appendFileSync, mkdirSync } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'registro');
try { mkdirSync(DIR, { recursive: true }); } catch (_) {}
const log = (t) => { try { appendFileSync(path.join(DIR, 'registro.log'), `[${new Date().toISOString()}] ${t}\n`); } catch (_) {} };
log(`main: node ${process.version} ${process.arch} args=${process.argv.slice(2).join(' ')}`);
try { await import('./app.js'); } catch (e) { log('falhou ao carregar: ' + (e && e.stack || e)); setTimeout(() => process.exit(1), 500); }
