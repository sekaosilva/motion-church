#!/bin/bash
# Instala o plugin Seraph no Ulanzi Studio e coloca o perfil "Seraph" do D200X.
cd "$(dirname "$0")" || exit 1
PASTA="$HOME/Library/Application Support/Ulanzi/UlanziDeck"
PLUGIN="br.seraph.deck.ulanziPlugin"
PERFIL="5e7a9b10-5e7a-4f00-9c11-5e7a9b10ce01.ulanziProfile"
echo "== Motion Church no Ulanzi Deck (plugin Seraph) =="
if [ ! -d "$PASTA" ]; then
  echo "Não achei a pasta do Ulanzi Studio. Abra o Ulanzi Studio uma vez e rode de novo."
  read -n 1 -s -r -p "Aperte uma tecla para fechar."; exit 1
fi
echo "Fechando o Ulanzi Studio…"
osascript -e 'tell application "Ulanzi Studio" to quit' >/dev/null 2>&1
for i in $(seq 1 40); do pgrep -f "Ulanzi Studio.app/Contents/MacOS/UlanziDeck" >/dev/null || break; sleep 0.5; done
pkill -f "$PLUGIN/plugin/" >/dev/null 2>&1
mkdir -p "$PASTA/Plugins" "$PASTA/ProfilesV2"
rm -rf "$PASTA/Plugins/$PLUGIN"
cp -R "$PLUGIN" "$PASTA/Plugins/" || { echo "Não consegui copiar o plugin."; read -n 1 -s -r; exit 1; }
xattr -dr com.apple.quarantine "$PASTA/Plugins/$PLUGIN" 2>/dev/null
echo "Plugin instalado."
# o perfil vai para o Deck D200X deste Mac (o número dele está nos perfis que o Ulanzi Studio já criou)
DECK=$(grep -ho '"Model":"D200X","UUID":"[^"]*"' "$PASTA"/ProfilesV2/*/manifest.json 2>/dev/null | grep -v __DECK__ | head -1 | sed 's/.*"UUID":"\([^"]*\)"/\1/')
if [ -z "$DECK" ]; then
  echo "Não achei o Ulanzi Creative Deck (D200X) no Ulanzi Studio."
  echo "Ligue o Deck no Mac, abra o Ulanzi Studio uma vez e rode este instalador de novo."
  open -a "Ulanzi Studio"; read -n 1 -s -r -p "Aperte uma tecla para fechar."; exit 1
fi
rm -rf "$PASTA/ProfilesV2/$PERFIL"
cp -R "perfil/$PERFIL" "$PASTA/ProfilesV2/" || { echo "Não consegui copiar o perfil."; read -n 1 -s -r; exit 1; }
for f in "$PASTA/ProfilesV2/$PERFIL/manifest.json" "$PASTA/ProfilesV2/$PERFIL"/Profiles/*/manifest.json; do
  sed -i '' -e "s|__PERFIS__|$PASTA/ProfilesV2|g" -e "s|__DECK__|$DECK|g" "$f"
done
echo "Perfil Seraph colocado (4 páginas do Motion Church)."
echo "Abrindo o Ulanzi Studio…"
open -a "Ulanzi Studio"
echo "Esperando o plugin ligar (20 s)…"
sleep 20
mkdir -p diagnostico
cp "$PASTA/Plugins/$PLUGIN/registro/registro.log" diagnostico/ 2>/dev/null && echo "Registro do plugin copiado." || echo "O plugin ainda não escreveu o registro."
echo
echo "Pronto. Se o Mac pedir para o Ulanzi Studio controlar o computador ou o System Events, clique em Permitir."
read -n 1 -s -r -p "Aperte uma tecla para fechar."
