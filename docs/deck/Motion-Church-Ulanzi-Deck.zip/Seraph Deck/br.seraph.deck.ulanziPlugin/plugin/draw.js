// Desenho dos ícones das teclas (196 x 196) e das telinhas dos botões giratórios.
// Usado pelo serviço do plugin (ícones que mudam: cronômetro, contagem, números)
// e pelo script que gera os ícones fixos.
import { createCanvas, GlobalFonts, Path2D, loadImage } from '@napi-rs/canvas';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import path from 'path';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
for (const f of ['ExtraBold', 'SemiBold', 'Bold', 'Black']) {
  try { GlobalFonts.registerFromPath(path.join(ROOT, 'resources/fonts', `Montserrat-${f}.ttf`), `Seraph ${f}`); } catch (_) {}
}
try { GlobalFonts.registerFromPath(path.join(ROOT, 'resources/fonts', 'SimbolosTeclas.ttf'), 'Seraph Simbolos'); } catch (_) {}
const GLYPHS = JSON.parse(readFileSync(path.join(ROOT, 'resources/glyphs.json'), 'utf8'));

export const S = 196;
export const COR = {
  fundo: '#0f1115',
  fundo2: '#1b1e25',
  texto: '#f4f5f7',
  apagado: '#8a8f99',
  azul: '#2b9bff',      // cor do Motion Church
  vermelho: '#ff4d4f',
  ambar: '#ffb020',
  verde: '#2fd27a',
  roxo: '#9b7bff',
};

function glyph(ctx, name, cx, cy, size, color, lw = 2) {
  const ds = GLYPHS[name];
  if (!ds) return;
  const k = size / 24;
  ctx.save();
  ctx.translate(cx - size / 2, cy - size / 2);
  ctx.scale(k, k);
  ctx.strokeStyle = color;
  ctx.lineWidth = lw;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  for (const d of ds) ctx.stroke(new Path2D(d));
  ctx.restore();
}

function fitText(ctx, text, maxW, size, weight = 'ExtraBold') {
  let s = size;
  do { ctx.font = `${s}px "Seraph ${weight}", "Seraph Simbolos"`; if (ctx.measureText(text).width <= maxW) break; s -= 1; } while (s > 10);
  return s;
}

function base(bg = COR.fundo) {
  const c = createCanvas(S, S);
  const ctx = c.getContext('2d');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, S, S);
  return { c, ctx };
}

function rotulo(ctx, label, color = COR.texto, y = 160, size = 24) {
  if (!label) return;
  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  fitText(ctx, label, S - 24, size);
  ctx.fillText(label, S / 2, y);
}

// Tecla com um desenho e um nome embaixo. "ligado" pinta a tecla com a cor de destaque.
export function teclaIcone({ icone, nome, cor = COR.azul, ligado = false, faixa = null }) {
  const { c, ctx } = base(ligado ? cor : COR.fundo);
  if (faixa) { ctx.fillStyle = faixa; ctx.fillRect(0, 0, S, 8); }
  glyph(ctx, icone, S / 2, 78, 84, ligado ? '#ffffff' : cor, 2);
  rotulo(ctx, nome, '#ffffff', 158, 25);
  return c.toBuffer('image/png');
}

// Tecla com um número grande (colunas do Motion Church).
export function teclaNumero({ numero, nome, cor = COR.azul }) {
  const { c, ctx } = base();
  ctx.fillStyle = COR.fundo2;
  ctx.beginPath(); ctx.roundRect(28, 18, S - 56, 112, 18); ctx.fill();
  ctx.fillStyle = cor;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.font = '92px "Seraph Black", "Seraph Simbolos"';
  ctx.fillText(String(numero), S / 2, 78);
  rotulo(ctx, nome, '#ffffff', 160, 24);
  return c.toBuffer('image/png');
}

// Tecla de texto livre (atalhos): uma "plaquinha" com o atalho e o nome embaixo.
export function teclaAtalho({ topo, nome, cor = COR.roxo, icone = null, app = '' }) {
  const { c, ctx } = base();
  ctx.fillStyle = cor; ctx.fillRect(0, 0, S, 8);
  const y0 = app ? 12 : 0;
  if (app) {
    ctx.fillStyle = cor; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    fitText(ctx, app.toUpperCase(), S - 30, 17, 'Bold'); ctx.fillText(app.toUpperCase(), S / 2, 30);
  }
  if (icone) glyph(ctx, icone, S / 2, 72 + y0, 70, cor, 2);
  else {
    ctx.fillStyle = COR.fundo2;
    ctx.beginPath(); ctx.roundRect(22, 34 + y0, S - 44, 72, 14); ctx.fill();
    ctx.fillStyle = cor; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    fitText(ctx, topo || '', S - 64, 40, 'Black');
    ctx.fillText(topo || '', S / 2, 71 + y0);
  }
  rotulo(ctx, nome, '#ffffff', 160, 24);
  return c.toBuffer('image/png');
}

// Relógio grande: cronômetro e contagem. "progresso" de 0 a 1 desenha um anel.
export function teclaTempo({ tempo, nome, cor = COR.verde, progresso = null, piscar = false }) {
  const { c, ctx } = base(piscar ? cor : COR.fundo);
  if (progresso != null) {
    ctx.lineWidth = 10; ctx.lineCap = 'round';
    ctx.strokeStyle = COR.fundo2;
    ctx.beginPath(); ctx.arc(S / 2, S / 2, 86, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = piscar ? '#ffffff' : cor;
    const p = Math.max(0, Math.min(1, progresso));
    if (p > 0) { ctx.beginPath(); ctx.arc(S / 2, S / 2, 86, -Math.PI / 2, -Math.PI / 2 + p * Math.PI * 2); ctx.stroke(); }
  }
  ctx.fillStyle = piscar ? '#ffffff' : COR.texto;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  fitText(ctx, tempo, 140, 50, 'Black');
  ctx.fillText(tempo, S / 2, 92);
  ctx.fillStyle = piscar ? '#ffffff' : cor;
  fitText(ctx, nome || '', 120, 19, 'Bold');
  ctx.fillText(nome || '', S / 2, 136);
  return c.toBuffer('image/png');
}

export const dataUrl = (buf) => 'data:image/png;base64,' + buf.toString('base64');

// Tecla de coluna ligada ao Motion Church: a miniatura do clipe, o número e o nome; no ar ganha moldura vermelha.
export async function teclaColuna({ numero, nome, miniatura = '', vivo = false, vazia = false, tipo = '' }) {
  const { c, ctx } = base();
  let temImg = false;
  if (miniatura) {
    try {
      const img = await loadImage(Buffer.from(miniatura.split(',')[1] || '', 'base64'));
      const s = Math.max(S / img.width, 132 / img.height);
      ctx.save(); ctx.beginPath(); ctx.rect(0, 0, S, 132); ctx.clip();
      ctx.drawImage(img, (S - img.width * s) / 2, (132 - img.height * s) / 2, img.width * s, img.height * s);
      ctx.restore(); temImg = true;
    } catch (_) {}
  }
  if (!temImg) {
    ctx.fillStyle = COR.fundo2; ctx.fillRect(0, 0, S, 132);
    if (tipo === 'text') glyph(ctx, 'mic-vocal', S / 2, 66, 64, vazia ? COR.apagado : COR.azul, 2);
  }
  // número
  ctx.fillStyle = vivo ? COR.vermelho : 'rgba(0,0,0,.72)';
  ctx.beginPath(); ctx.roundRect(10, 10, 54, 46, 10); ctx.fill();
  ctx.fillStyle = '#ffffff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.font = '34px "Seraph Black"'; ctx.fillText(String(numero), 37, 34);
  // nome
  ctx.fillStyle = vivo ? COR.vermelho : COR.fundo; ctx.fillRect(0, 132, S, 64);
  ctx.fillStyle = vazia ? COR.apagado : '#ffffff';
  const t = vazia ? 'Vazia' : (nome || 'Coluna');
  fitText(ctx, t, S - 20, 24, 'ExtraBold');
  ctx.fillText(t, S / 2, 165);
  if (vivo) { ctx.strokeStyle = COR.vermelho; ctx.lineWidth = 10; ctx.strokeRect(5, 5, S - 10, S - 10); }
  if (vazia) { ctx.fillStyle = 'rgba(15,17,21,.55)'; ctx.fillRect(0, 0, S, 132); }
  return c.toBuffer('image/png');
}

// Tecla "Abrir Motion Church": o ícone do programa; com o programa aberto e ligado, faixa verde e "Aberto".
const APP_ICONE = path.join(ROOT, 'resources/mc-app.png');
export async function teclaApp({ aberto = false }) {
  const { c, ctx } = base();
  try { const img = await loadImage(APP_ICONE); ctx.drawImage(img, 43, 14, 110, 110); } catch (_) {}
  if (aberto) { ctx.fillStyle = COR.verde; ctx.fillRect(0, 0, S, 8); }
  rotulo(ctx, aberto ? 'Aberto' : 'Abrir', aberto ? COR.verde : '#ffffff', 158, 25);
  return c.toBuffer('image/png');
}
