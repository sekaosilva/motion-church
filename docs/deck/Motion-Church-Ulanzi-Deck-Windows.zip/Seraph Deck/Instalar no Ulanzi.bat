@echo off
rem Instala o plugin Seraph (Motion Church) no Ulanzi Studio
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
